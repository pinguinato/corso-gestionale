<?php
		echo "<meta name='viewport' content='width=device-width, initial-scale=1'>";
		echo "<link rel='stylesheet' href='bootstrap-3.3.7-dist/css/bootstrap.css'>";
		echo "<link rel='stylesheet' href='bootstrap-3.3.7-dist/css/bootstrap-theme.min.css'>";
		echo "<script src='bootstrap-3.3.7-dist/js/jquery-3.1.1.min.js'></script>";
		echo "<script src='bootstrap-3.3.7-dist/js/bootstrap.min.js'></script>";
		echo "<link rel='stylesheet' href='font-awesome-4.7.0/css/font-awesome.min.css'>";
?>